﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ProyVentas_BL;

public partial class WEBFacturacionCliente : System.Web.UI.Page

{
    ClienteBL CliBL = new ClienteBL();
    FacturaBL FacBL = new FacturaBL();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if(Page.IsPostBack == false)
            {
            }

        }catch(Exception ex)
        {

        }
    }

    protected void btnConsultar_Click(object sender, EventArgs e)
    {
        try
        {
            String codcli = cboCliente.SelectedValue.ToString();
            DateTime fi = Convert.ToDateTime(txtFI.Text.Trim());
            DateTime ff = Convert.ToDateTime(txtFF.Text.Trim());
        }
        catch(Exception ex)
        {
            lblMensaje.Text = ex.Message;
        }
    }
}